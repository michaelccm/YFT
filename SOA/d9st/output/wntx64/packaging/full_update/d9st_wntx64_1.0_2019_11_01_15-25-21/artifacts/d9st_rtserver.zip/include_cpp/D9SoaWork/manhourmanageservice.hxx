/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@

 ==================================================

   Auto-generated source from service interface.
                 DO NOT EDIT

 ==================================================
*/
#ifndef TEAMCENTER_SERVICES_WORK_MANHOURMANAGESERVICE_HXX 
#define TEAMCENTER_SERVICES_WORK_MANHOURMANAGESERVICE_HXX


#include <manhourmanageservice1806.hxx>


namespace D9
{
    namespace Soa
    {
        namespace Work
        {
            class ManHourManageService;
        }
    }
}


/**
 * ManHourManageService
 * <br>
 * <br>
 * <br>
 * <b>Library Reference:</b>
 * <ul>
 * <li type="disc">libd9soawork.dll
 * </li>
 * </ul>
 */

class D9::Soa::Work::ManHourManageService
    : public D9::Soa::Work::_2018_06::ManHourManageService
{};

#endif

